const Loading = () => {
  return <div className="bg-gray-dark fixed inset-0 z-50 flex items-center justify-center bg-opacity-30">로딩중</div>;
};

export default Loading;
